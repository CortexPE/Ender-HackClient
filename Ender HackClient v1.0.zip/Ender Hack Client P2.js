//Copyright © 2016 c0rt3xg4m1ng//
//SOME SCRIPTS ARE BY WILCO375, CODER_G, POCKETGAMER123, ARJAY07.//
//DO NOT COPY,MODIFY,OR COPY PARTS OF THIS MOD OR I'LL SUE YOI WITH COPYRIGHT.//

	
//START OF CODE//

//CUSTOM TEXT//
{	ModPE.langEdit("menu.play","§b§l§oPlay");
ModPE.langEdit("menu.skins","§b§l§6Clothes");
ModPE.langEdit("menu.copyright","§b§I§3[Ender HackClient] © Ralph");
ModPE.langEdit("playscreen.header.local","§6Select World/Server");
ModPE.langEdit("deathScreen.message","§b§4Wasted");
ModPE.langEdit("deathScreen.quit","Give up");
ModPE.langEdit("progressScreen.generating","Wait for the line to turn Green.");
ModPE.langEdit("pauseScreen.quit","Give up");
ModPE.langEdit("chestScreen.header.small","Single Chest");
ModPE.langEdit("chatScreen.hide","Mute Chat");
ModPE.langEdit("container.chest","Single Chest");
ModPE.langEdit("chestScreen.header.player","Treasure");
ModPE.langEdit("menu.options","§2Settings");
}
//COMMANDS//
var mPlayer = new android.media.MediaPlayer();
 var path =
android.os.Environment.getExternalStorageDirectory().getAbsolutePath(); 
 var vertexX=0 
 var vertexY=0 
 var vertexZ=0 
 Level.getAddress(); 
 Level.getWorldDir(); 
 Level.getWorldName(); 
 getPlayerX(); getPlayerY(); getPlayerZ(); 

function procCmd(cmd){

//About//

if(cmd == "about"){
clientMessage("§2====================");
clientMessage("§3Ender HackClient(§2v.1.0) §1By §3§b§ic0r73xg4m1ng");
clientMessage("For suggestions email me on §4G§3M§2A§6I§4L"); clientMessage("Gmail§2: mcpe4life62@gmail.com");
clientMessage("§2====================");
}

//heal//

if(cmd == "heal"){
Player.setHealth(20);
clientMessage("§aYou have been healed!");
}



if(cmd == "health infinite"){
Player.setHealth(999999);
clientMessage("§aYou have been healed!");
}

//time help//

if(cmd == "time help"){
clientMessage("§7To set the time");
clientMessage("§7Usage: §f/timeset §6[day/midday/noon/night/midnight]");
clientMessage("§f/time §7Shows the §6time");
}

//starterkit//

if(cmd == "kit"){
clientMessage("§7/kit §6[starter/iron]");
}

if(cmd == "kit starter"){
Player.addItemInventory(17, 15, 0);
Player.addItemInventory(12, 15, 0);
Player.addItemInventory(4, 15, 0);
Player.addItemInventory(272, 1, 0);
Player.addItemInventory(273, 1, 0);
Player.addItemInventory(274, 1, 0);
Player.addItemInventory(275, 1, 0);
Player.addItemInventory(291, 1, 0);
Player.addItemInventory(298, 1, 0);
Player.addItemInventory(299, 1, 0);
Player.addItemInventory(300, 1, 0);
Player.addItemInventory(301, 1, 0);
Player.addItemInventory(364, 6, 0);
clientMessage("§7You get");
clientMessage("§b15 §6Oak Wood");
clientMessage("§b15 §6Sand");
clientMessage("§b15 §6Cobblestone");
clientMessage("§b1 §6Stone Sword");
clientMessage("§b1 §6Stone Shovel");
clientMessage("§b1 §6Stone Pickaxe");
clientMessage("§b1 §6Stone Axe");
clientMessage("§b1 §6Stone Hoe");
clientMessage("§b1 §6Leather Helmet");
clientMessage("§b1 §6Leather Tunie");
clientMessage("§b1 §6Leather Pants");
clientMessage("§b1 §6Leather Boots");
clientMessage("§b6 §6Steak");
}

//iron//
if(cmd == "kit iron"){
Player.addItemInventory(17, 20, 0);
Player.addItemInventory(12, 20, 0);
Player.addItemInventory(4, 20, 0);
Player.addItemInventory(322, 2, 0);
Player.addItemInventory(256, 1, 0);
Player.addItemInventory(257, 1, 0);
Player.addItemInventory(258, 1, 0);
Player.addItemInventory(267, 1, 0);
Player.addItemInventory(292, 1, 0);
Player.addItemInventory(305, 1, 0);
Player.addItemInventory(304, 1, 0);
Player.addItemInventory(303, 1, 0);
Player.addItemInventory(302, 1, 0);
Player.addItemInventory(364, 10, 0);
clientMessage("§7You get");
clientMessage("§b20 §6Oak Wood");
clientMessage("§b20 §6Sand");
clientMessage("§b20 §6Cobblestone");
clientMessage("§b1 §6Iron Hoe");
clientMessage("§b1 §6Iron Sword");
clientMessage("§b1 §6Iron Pickaxe");
clientMessage("§b1 §6Iron Axe");
clientMessage("§b1 §6Iron Shovel");
clientMessage("§b1 §6Chainmail Helmet");
clientMessage("§b1 §6Chainmail Chestplate");
clientMessage("§b1 §6Chainmail Leggings");
clientMessage("§b1 §6Chailmail Boots");
clientMessage("§b2 §6Golden Apple");
clientMessage("§b10 §6Steaks");
}

//weather//

if(cmd == "weather"){
Level.setRainLevel(1);
clientMessage("§7Usage: §f/weather [rain/lightning/stop/strorm]");
}

if(cmd == "weather rain"){
Level.setRainLevel(1);
clientMessage("§7Its §6rain!");
}



//weather stop//
if(cmd == "weather stop"){
Level.setRainLevel(0);
Level.setLightningLevel(0);
clientMessage("§7Weather §6stopped!");
}



//weather lightning//
if(cmd == "weather lightning"){
Level.setLightningLevel(1);
clientMessage("§7Its §6Lightning!");
}



//weather storm//
if(cmd == "weather storm"){
Level.setLightningLevel(1);
Level.setRainLevel(1);
clientMessage("§7Its §6Stormy!");
}

//GIVE//

//for(i=0 ; i<cline.length; i++ ) { clientMessage(Player.getName(getPlayerEnt()) + " " + cline[i]);
               //Sum += i;
var cline=cmd.split(" ");

    	switch(cline[0]) {
//give
case "give":
          if(!parseInt(cline[2])) {
                 clientMessage("§7Usage: §f/give §b<item> §6<amount> §e[damage]");
          } else if(!parseInt(cline[1])) {
                 clientMessage("§7There is no such id as §c\"" + cline[1] + "\"");
          } else {
          Player.addItemInventory(cline[1], cline[2], cline[3]);
          clientMessage("§7Given " + "§b[§f" +cline[1] + "§b]§f" + " * " + cline[2] + " §7to §e" + Player.getName(getPlayerEnt()));
          break;
          }
          
          
          
          
          break;
//tp//
          case "tp":
          if(!parseInt(cline[1] || cline[2] || cline[3])) {
                clientMessage("§7Usage: /tp <x> <y> <z>");
          } else {
          Entity.setPosition(getPlayerEnt(), cline[1], cline[2], cline[3]);
          }
          switch (cline[1]) {
          	case "entity": 
          		var eX = Entity.getX(cline[2]);
          		var eY = Entity.getY(cline[2]);
          		var eZ = Entity.getZ(cline[2]);
          		var eY1 = eY + 1;
          		Entity.setPosition(getPlayerEnt(), eX, eY1, eZ);
          		}
          		//coords
          		 case "coords":
		if (cline[1] == undefined) {
			var cX = getPlayerX();
			var cY = getPlayerY();
			var cZ = getPlayerZ();
			clientMessage("§bx: §f" + Math.round(cX) + " §by:§f " + Math.round(cY) + " §bz:§f " + Math.round(cZ));
		} 
		switch(cline[1]) {
             case "pointed":
                    clientMessage("x: " + Math.round( Player.getPointedBlockX()) + " y: " + Math.round( Player.getPointedBlockY()) + " z: " + Math.round( Player.getPointedBlockZ()));
             break;
		}
		
		
     break;
//setspawn
     case "spawnpoint":
		Level.setSpawn(getPlayerX(), getPlayerY(), getPlayerZ());
        clientMessage("§7Spawnpoint set to§6 x:§f" + Player.getPointedBlockX() + " §6y:§f" + Player.getPointedBlockY() + " §6z:§f" + Player.getPointedBlockZ());
      break;
          		}

    	            
    	
    	
    	

//SUICIDE//
if(cmd == "kill"){
Player.setHealth(0);
clientMessage("§fYou §ckilled §fyourself");
}



//GAMEMODE CHANGE//


//Creative//
if(cmd == "gmc"){
Level.setGameMode(1);
clientMessage("§7You Changed the gamemode §6Creative!");
}

if(cmd == "gm 1"){
Level.setGameMode(1);
clientMessage("§7You Changed the gamemode §6Creative!");
}

if(cmd == "gamemode 1"){
Level.setGameMode(1);
clientMessage("§7You Changed the gamemode §6Creative!");
}

if(cmd == "gamemode creative"){
Level.setGameMode(1);
clientMessage("§7You Changed the gamemode §6Creative!");
}


//Survival//
if(cmd == "gms"){
Level.setGameMode(0);
clientMessage("§7You Changed the gamemode §6Survival!");
}
if(cmd == "gamemode survival"){
Level.setGameMode(0);
clientMessage("§7You Changed the gamemode §6Survival!");
}
if(cmd == "gamemode 0"){
Level.setGameMode(0);
clientMessage("§7You Changed the gamemode §6Survival!");
}
if(cmd == "gm 0"){
Level.setGameMode(0);
clientMessage("§7You Changed the gamemode §6Survival!");
}




//Adventure//
if(cmd == "gma"){
Level.setGameMode(2);
clientMessage("§7You Changed the gamemode §6Adventure!");
}

if(cmd == "gamemode adventure"){
Level.setGameMode(2);
clientMessage("§7You Changed the gamemode §6Adventure!");
}

if(cmd == "gm 2"){
Level.setGameMode(2);
clientMessage("§7You Changed the gamemode §6Adventure!");
}

if(cmd == "gamemode 2"){
Level.setGameMode(2);
clientMessage("§7You Changed the gamemode §6Adventure!");
}






//lvl//

if(cmd == "lvl"){
clientMessage("§7Usage: §f/lvl [50/100]");
}


if(cmd == "lvl 100"){
Player.setLevel(100);
clientMessage("§7You are now lvl §e1§c0§90!");
}


          
if(cmd == "lvl 50"){
Player.setLevel(50);
clientMessage("§7You are now lvl §650!");
}
                 
                 
                 
//world//
if(cmd == "world"){
clientMessage("§7The world name is -§6" + Level.getWorldName());
}

//hit//
if(cmd == "hit"){
clientMessage("§7Usage: §f/hit [off/on]");
}


//Gamespeed//

if(cmd == "gs"){
clientMessage("§7Usage: §f/gs [normal/2/3]");
}


if(cmd == "gs normal"){
ModPE.setGameSpeed(20);
clientMessage("§7The Gamespeed is now Back to §b§2Normal!");
}


          
if(cmd == "gs 2"){
ModPE.setGameSpeed(40);
clientMessage("§7The Gamespeed is now §b§6Faster!");
}


if(cmd == "gs 3"){ ModPE.setGameSpeed(100)
;
clientMessage("§7The Gamespeed is now the §b§4Fastest!");
}        
                 
                 
                 
//help//
if(cmd == "help"){
clientMessage("§7Help page §b1 §7of §64");
clientMessage("§b/About§6 >>§7  Is a little Info §eabout me");
clientMessage("§b/clear§6 >>§7 Clears the §eSurvival§7 Inventory");
clientMessage("§b/gm §6>>§7 Enables §e1");
clientMessage("§b/coords§6 >>§7  Shows the §exzy§7 coordinats");
clientMessage("§b/fly §6 >>§7  Player can §eflys §7in Survival gamemode");
clientMessage("§b/give§6 >>§7  Gives you some §eitems");
clientMessage("§b/gma§6 >>§7  Sets your gamemode to §eAdventure");
clientMessage("·");
clientMessage("§7Do §6>>§e /help commands §6<< §7to get more infos about the commands.");
}           




      if(cmd == "help 2"){
clientMessage("§7Help page §b2 §7of §64");
clientMessage("§b/gmc§6 >>§7  Sets your gamemode to §eCreative");
clientMessage("§b/gs§6 >>§7  Sets your GameSpeed");
clientMessage("§b/gms§6 >>§7  Sets your gamemode to §eSurvival");
ientMessage("§b/help§6 >>§7  Shows the §ehelp §7list");
clientMessage("§b/kill§6 >>§7  Suicide");


}                 



                 
    if(cmd == "help 3"){
clientMessage("§7Help page §b3 §7of §64");
clientMessage("§b/home§6 >>§7 Teleports you to your§e home");
clientMessage("§b/kit§6 >>§7  Gives you a §estarterkit");
clientMessage("§b/lvl§6 >>§7  Sets your §elevel§7");
clientMessage("§b/sethome§6 >> §7Sets your §6home§7 spawnpoint");
clientMessage("§b/spawnpoint§6 >> §7Sets the world §espawn point");
clientMessage("§b/time §6>>§7 Shows the §etime");
clientMessage("§b/hit §6>>§7 Enables §e1 Hit 1 Kill")

}
            
            
            
    if(cmd == "help 4"){
clientMessage("§7Help page §b4 §7of §64");
clientMessage("§b/timeset§6 >>§7  Sets the §etime");
clientMessage("§b/tp §6>>§7 Teleports you to the selected §ecoordinats");
clientMessage("§b/weather§6 >>§7  Controll the§e weather");      
clientMessage("§b/world§6 >>§7  Shows the§e world§7 name");     
        
}







//showXYZ//
if(cmd == "coords"){
Player.getPointedBlockX();
Player.getPointedBlockY();
Player.getPointedBlockZ();
clientMessage("§7Here are the §6coordinats >> §bx" + Player.getPointedBlockX() + ("§7, §by") + Player.getPointedBlockY() + ("§7, §bz") + Player.getPointedBlockZ());
}





//nightmode//
if(cmd == "nightmode"){
clientMessage("§7Usage: §f/nightmode [off/on]");
}
if(cmd == "nightmode on"){
Level.setNightMode(1);
clientMessage("§7You set the §7time§6 faster§7!")
}
if(cmd == "nightmode off"){
Level.setNightMode(0); 
}



//hunger//
if(cmd == "hunger on"){
Player.setHunger(0);
clientMessage("§7You are now§6 hungry!");
}
if(cmd == "hunger off"){
Player.setHunger(1);
}





//time set//
if(cmd == "timeset"){
Level.setTime(0);
clientMessage("§7Usage: §f/time [day/midday/noon/night/midnight]");
}


if(cmd == "timeset day"){
Level.setTime(0);
clientMessage("§7You set the time to §eday§7!");
}

if(cmd == "timeset midday"){
Level.setTime(4500);
clientMessage("§7You set the time to §emidday§7!");
}

if(cmd == "timeset noon"){
Level.setTime(8000);
clientMessage("§7You set the time to §enoon§7!");
}

if(cmd == "timeset night"){
Level.setTime(14000);
clientMessage("§7You set the time to §enight§7!");
}

if(cmd == "timeset midnight"){
Level.setTime(18000);
clientMessage("§7You set the time to §emidnight§7!");
}
//
if(cmd == "time"){
clientMessage("§7The time is §e" + Level.getTime());
}


//fly//

if(cmd == "fly"){
clientMessage("§7Usage: §f/fly [on/off]");
}

if(cmd == "fly on"){
Player.setCanFly(1);
clientMessage("§aFly enabled!");
}

if(cmd == "fly off"){
Player.setCanFly(0);
clientMessage("§cFly disabled!");
}












//sethome//

 if(cmd[0] == "sethome") { ModPE.saveData("vertexX",parseInt(Player.getX())); ModPE.saveData("vertexY",parseInt(Player.getY())); ModPE.saveData("vertexZ",parseInt(Player.getZ())); } 

if(cmd[0] == "sethome") { 
clientMessage(" §7Home set to §bx§f: " + Math.floor(ModPE.readData("vertexX")) + ", §by§f: " + Math.floor(ModPE.readData("vertexY")) + ", §bz§f: " + Math.floor(ModPE.readData("vertexZ"))); }

//home//


 if(cmd[0] == "home") { Entity.setPosition(Player.getEntity(), parseInt(ModPE.readData("vertexX")) + 0, parseInt(ModPE.readData("vertexY")) + 0.7, parseInt(ModPE.readData("vertexZ")) + 0.5); } 
 if(cmd[0] == "home") {
  clientMessage("§7Teleported to §bhome!");
  }
}

//ZOOM//

var zoom = false
function newLevel()
{
clientMessage("[EHC] §b§2Ender HackClient Part 2 Loaded Successfully!");

var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get(); 
ctx.runOnUiThread(new java.lang.Runnable(){
 
run: function(){
 
try{
GUIButton = new android.widget.PopupWindow();
var layoutButton = new android.widget.LinearLayout(ctx);
layoutButton.setOrientation(android.widget.LinearLayout.VERTICAL);
GUIButton.setContentView(layoutButton);
GUIButton.setWidth(30);
GUIButton.setHeight(30);
var btnButton = new android.widget.Button(ctx);
layoutButton.addView(btnButton);
btnButton.setText("z");
btnButton.setOnClickListener(new android.view.View.OnClickListener({ 
onClick: function(viewarg)
{
if(zoom==false)
{
ModPE.setFov(20);
zoom = true;
}
else if(zoom==true)
{
ModPE.setFov(70);
zoom = false;
}
}
}));
GUIButton.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM, 5, 2);
}
catch(e)
{
print("Failed on Zooming!");
}
}
})
}
//END OF CODE//

//DO NOT COPY//


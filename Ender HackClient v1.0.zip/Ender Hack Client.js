//Copyright © 2016 c0rt3xg4m1ng//
//SOME SCRIPTS ARE BY WILCO375, CODER_G, POCKETGAMER123, ARJAY07.//
//DO NOT COPY,MODIFY,OR COPY PARTS OF THIS MOD OR I'LL SUE YOI WITH COPYRIGHT.//

//HACK Button//
var GUI;
function newLevel(){
var ctx = com.mojang.minecraftpe.MainActivity.currentMainActivity.get();
ctx.runOnUiThread(new java.lang.Runnable({ run: function(){
try{
var layout = new android.widget.LinearLayout(ctx);
layout.setOrientation(1);

clientMessage("[EHC]§b§2Ender HackClient Part 1 Loaded Successfully!")

var button = new android.widget.Button(ctx);
button.setText('Hack!');
button.setOnClickListener(new android.view.View.OnClickListener({
onClick: function(viewarg){

Player.setCanFly(1)


Player.addItemInventory(310, 64, 0)
Player.addItemInventory(311, 64, 0)
Player.addItemInventory(312, 64, 0)
Player.addItemInventory(313, 64, 0)
Player.addItemInventory(276, 64, 0)
Player.addItemInventory(261, 64, 0)
Player.addItemInventory(262, 64, 0)
Player.addItemInventory(297, 64, 0)
Player.addItemInventory(322, 64, 0)

Player.setHealth("1000")
}
}));
layout.addView(button);

GUI = new android.widget.PopupWindow(layout, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
GUI.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
GUI.showAtLocation(ctx.getWindow().getDecorView(), android.view.Gravity.LEFT | android.view.Gravity.TOP, 280, 0);
}catch(err){
print('An error has occured please reinstall: ' + err);
}
}}));
}

//DIAMOND RAIN//
function useItem (x, y, z, itemId, blockId, side) {if (itemId==280&&blockId!=0) {preventDefault (); Level.dropItem(x,y+5,z,0,264,10); Level.dropItem(x-1,y+5,z,0,264,5); Level.dropItem(x-1,y+5,z+1,0,264,5); Level.dropItem(x,y+5,z-1,0,264,5); Level.dropItem(x,y+5,z+1,0,264,5); Level.dropItem(x-1,y+5,z-1,0,264,5); Level.dropItem(x+1,y+5,z+1,0,264,5); Level.dropItem(x+1,y+5,z,0,264,5); Level.dropItem(x+1,y+5,z+1,0,264,5); }}

//NO FALL-DAMAGE//
var falling = false;
function modTick(){
if(Entity.getVelY(Player.getEntity()) <= -0.5 && !falling)
{
Entity.addEffect(Player.getEntity(),
MobEffect.jump, 1000*1000, 1000, false, false);
falling = true;
}
if(falling==true)
{
if(Level.getTile(Math.floor(Player.getX()),Math.floor(Player.getY()) - 2,Math.floor(Player.getZ())) > 0)
{
if(Entity.getVelY(Player.getEntity()) == -0.07840000092983246 )
{
falling = false;
{
Entity.removeEffect(Player.getEntity(),
MobEffect.jump);
Entity.addEffect(Player.getEntity(),
MobEffect.jump, 3*3, -1, false, false);
}
}
}
}
}

//1 HIT 1 KILL//
var hit = 0
function procCmd(c)
 {
	var p = c.split(" ");
	var command = p[0];
	switch(command)
{
case 'hit':
{
if(p[1]=='on')
{
hit = 1
clientMessage("1 hit 1 kill activated");
}
if(p[1]=='off')
{
hit = 0
clientMessage("1 hit 1 kill deactivated");
}
}
break;
}
}
function attackHook(attacker, victim)
{
if(hit == 1)
{
Entity.setHealth(victim,1)
}
}

//Walk on water//
//W.I.P.//

//GOODBYE MESSAGE//
function leaveGame(){
savedata = true;
print("Goodbye! And Thank You For using Ender HackClient");
}

//No block gravity//
//With OPTIFINE//
//NULL//

// DO NOT COPY //
